# ShowPapers whitepaper source

This bundle contains the published manuscript for specification 1.0.0, its editable Mermaid diagrams, and the rendered figure PDFs used by the manuscript.

## Build the PDF

Install a TeX distribution with latexmk, pdfLaTeX and Latin Modern (for example, MacTeX or TeX Live). Extract the complete ZIP, including its .build directory, into a new directory. From that directory run:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error showpapers-whitepaper.tex
```

The result is showpapers-whitepaper.pdf in the extracted directory. The four figure PDFs are already included, so compiling the paper requires no Node.js, browser or Mermaid installation.

## Edit a diagram

Editable sources and their renderer configuration are in diagrams/. The published diagrams were rendered with Mermaid CLI 11.17.0. To change one, render its .mmd source to the corresponding .build/<name>.pdf using diagrams/config.json, then recompile the manuscript. Keep the manuscript, figure PDFs and published PDF together when proposing a change.

## Publication

Canonical publication: https://github.com/liminalatoms/showpapers-format
Paper and HTML edition: https://protocol.showpapers.app/whitepaper
Website source revision: https://protocol.showpapers.app/source.json

The website imports a reviewed repository commit. It must use the same paper and source bundle; repository updates do not automatically deploy the website.

The work is licensed under Apache License 2.0. The included LICENSE contains the full terms; NOTICE names the whitepaper authors and includes attribution and citation guidance. CITATION.cff supplies machine-readable citation metadata. Please cite the whitepaper and relevant protocol version for software, research, technical publications or patent applications that use or build upon this work. This citation request adds no license conditions and does not replace applicable patent-disclosure obligations.
