# ShowPapers technical whitepaper

The canonical manuscript is `showpapers-whitepaper.tex`. Its four diagrams are editable Mermaid sources under `diagrams/`. The PDF and HTML editions share the manuscript, diagram labels, captions and references.

From the repository root, install the pinned diagram renderer and export:

```sh
cd site
npm ci
cd ..
python3 whitepaper/build.py
```

The exporter requires `latexmk`, `pdflatex`, Latin Modern and Chrome/Chromium. Set `SHOWPAPERS_DIAGRAM_BROWSER` to an installed browser executable when the default macOS Chrome path does not apply. Mermaid CLI 11.17.0 is pinned in `site/package-lock.json`; it runs during export. No external font or diagram service is used. Intermediate files stay in `whitepaper/.build/`.

Export creates the website PDF, HTML reading edition, SVG diagrams, Mermaid source downloads and `whitepaper-source.zip`. It refuses stale specification versions, unresolved references and overfull LaTeX boxes. Rebuild the site after export with `cd site && npm run validate`.

The downloadable source bundle includes the manuscript, Mermaid sources and generated diagram PDFs. Extract it and run `latexmk -pdf showpapers-whitepaper.tex` to compile without regenerating diagrams. The manuscript is a document project with figure dependencies; a single-file LaTeX compiler cannot build it alone.

Review every rendered PDF page after changes. The report explains specification 1.0.0: collection records, review and import rules, agent exchange, validation and the protected envelope. Keep the manuscript, captions and concrete trust boundaries consistent with the specification. The repository Apache 2.0 license applies.

## September 30 editorial review

An independent GPT-6 Astra source review compared the manuscript and diagrams against the public contracts. The revisions distinguish accepting an agent proposal from confirming its value, preserve each detail's original source, separate full-collection validation from exact-base changes validation, and limit the conclusion's attribution claim to agent-proposed details. A second review found no remaining substantive discrepancy. This is a manuscript review, not a native implementation or security audit.

The report now defines originals, readings, paper records and provenance in plain language and explains cloud AI disclosure and the conditions for local processing. The PDF was regenerated from Mermaid and LaTeX and reviewed visually across all ten pages. The HTML edition and downloadable PDF/source bundle share the same revised content.

## October 1 protocol update

The report now explains inventorying an existing collection before adding files, comparing original-file digests, reusing suitable folders and preserving the parent tree through selected export and import. The review-state wording describes the receiving app's policy without claiming the removed import toggle is visible. All four Mermaid diagrams use more readable spacing and labels; the exchange diagram includes folder matching before the return archive or changes document. The October PDF has eleven pages, with matching HTML and downloadable sources.

A focused independent source review checked these changes against the protocol and both native import planners. It identified and corrected one overbroad statement about incoming relationship decisions. All eleven rendered pages were visually reviewed; phone and desktop browser checks verified diagrams and both PDF download buttons. Publication is coordinated with the native hierarchy update so the paper does not get ahead of the app's support.

## October 2 import and checklist clarification

The report distinguishes direct updates from complete collection imports from the separate review workflow for changes documents. It no longer promises that every conflicting incoming record is kept local until a per-record choice. The provenance section retains the existing trust and confidence admission rules, while the record section explains canonical native checklist markers and UTF-16 formatting ranges. This is an editorial clarification of the existing serialized format; specification and archive versions are unchanged.
